import { NgModule } from '@angular/core';
import { SkeletonItemComponent } from './skeleton-item/skeleton-item';
@NgModule({
	declarations: [SkeletonItemComponent],
	imports: [],
	exports: [SkeletonItemComponent]
})
export class ComponentsModule {}
